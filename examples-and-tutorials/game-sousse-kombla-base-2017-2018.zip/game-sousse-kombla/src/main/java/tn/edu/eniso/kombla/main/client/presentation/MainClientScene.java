/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.eniso.kombla.main.client.presentation;

//import net.vpc.gaming.atom.debug.layers.DebugLayer;

import net.vpc.gaming.atom.annotations.AtomScene;
import net.vpc.gaming.atom.annotations.Inject;
import net.vpc.gaming.atom.annotations.OnInstall;
import net.vpc.gaming.atom.engine.SceneEngine;
import net.vpc.gaming.atom.model.Sprite;
import net.vpc.gaming.atom.presentation.DefaultScene;
import net.vpc.gaming.atom.presentation.ImageMatrixProducer;
import tn.edu.eniso.kombla.main.client.engine.MainClientEngine;
import tn.edu.eniso.kombla.main.local.presentation.MainLocalScene;
import tn.edu.eniso.kombla.main.shared.prensentation.BomberScene;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * @author Taha Ben Salah (taha.bensalah@gmail.com)
 */
@AtomScene(
        id = "mainClient",
        engine = "mainClient",
        title = "Kombla - Client",
        tileWidth = 40,
        isometric = false
        , cameraWidth = 1f
)
public class MainClientScene extends BomberScene {

    @Inject
    SceneEngine engin;

    public MainClientScene() {
    }

    @OnInstall
    private void onInstall() {
        engin.addPropertyChangeListener("modelChanged", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                updateControl();
            }
        });
    }

    protected void updateControl() {
        MainClientEngine sceneEngine = getSceneEngine();
        Sprite sprite = sceneEngine.findSpriteByKind("Person");
        if (sprite != null) {
            lockCamera(sprite);
            resetControlPlayers();
            addControlPlayer(sceneEngine.getCurrentPlayerId());
        }
    }

}
