/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.edu.eniso.kombla;

import net.vpc.gaming.atom.Atom;

/**
 * @author Taha Ben Salah (taha.bensalah@gmail.com)
 */
public class KomblaGame {

    public static void main(String[] args) {
        Atom.startGame();
    }
}
