package tn.edu.eniso.kombla.welcome;

import net.vpc.gaming.atom.annotations.AtomSceneEngine;

/**
 * Created by vpc on 10/7/16.
 */
@AtomSceneEngine(id = "welcome",welcome = true)
public class WelcomeEngine {
}
