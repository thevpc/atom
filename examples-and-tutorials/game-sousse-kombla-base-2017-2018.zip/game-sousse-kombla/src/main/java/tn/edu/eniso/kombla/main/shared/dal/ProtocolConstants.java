package tn.edu.eniso.kombla.main.shared.dal;

/**
 * Created by vpc on 10/7/16.
 */
public class ProtocolConstants {
    public static final int CONNECT = 1;
    public static final int LEFT = 2;
    public static final int RIGHT = 3;
    public static final int UP = 4;
    public static final int DOWN = 5;
    public static final int FIRE = 6;
    public static final int OK = 7;
    public static final int KO = 8;
}
